/* Copyright (c) Mark Harmstone 2016-17
 *
 * This file is part of WinBtrfs.
 *
 * WinBtrfs is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public Licence as published by
 * the Free Software Foundation, either version 3 of the Licence, or
 * (at your option) any later version.
 *
 * WinBtrfs is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public Licence for more details.
 *
 * You should have received a copy of the GNU Lesser General Public Licence
 * along with WinBtrfs.  If not, see <http://www.gnu.org/licenses/>. */

#include <stdlib.h>
#include <stddef.h>
#include <time.h>
#include <ntstatus.h>
#define WIN32_NO_STATUS
#include <windef.h>
#include <winbase.h>
#include <winternl.h>
#include <devioctl.h>
#include <ntdddisk.h>
#include <ntddscsi.h>
#include <ntddstor.h>
#include <ata.h>
#include <mountmgr.h>
#include <stringapiset.h>
#include <stdbool.h>
#include "../btrfs.h"
#include "../btrfsioctl.h"
#include "../crc32c.h"
#include "../zstd/lib/common/xxhash.h"

#if defined(_X86_) || defined(_AMD64_)
#ifndef _MSC_VER
#include <cpuid.h>
#else
#include <intrin.h>
#endif
#endif

#define SHA256_HASH_SIZE 32
void calc_sha256(uint8_t* hash, const void* input, size_t len);

#define BLAKE2_HASH_SIZE 32
void blake2b(void *out, size_t outlen, const void* in, size_t inlen);

#define FSCTL_LOCK_VOLUME               CTL_CODE(FILE_DEVICE_FILE_SYSTEM,  6, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define FSCTL_UNLOCK_VOLUME             CTL_CODE(FILE_DEVICE_FILE_SYSTEM,  7, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define FSCTL_DISMOUNT_VOLUME           CTL_CODE(FILE_DEVICE_FILE_SYSTEM,  8, METHOD_BUFFERED, FILE_ANY_ACCESS)

#ifndef _MSC_VER // not in mingw yet
#define DEVICE_DSM_FLAG_TRIM_NOT_FS_ALLOCATED 0x80000000
#endif

#ifdef __cplusplus
extern "C" {
#endif
NTSTATUS NTAPI NtWriteFile(HANDLE FileHandle, HANDLE Event, PIO_APC_ROUTINE ApcRoutine, PVOID ApcContext, PIO_STATUS_BLOCK IoStatusBlock, PVOID Buffer,
                           ULONG Length, PLARGE_INTEGER ByteOffset, PULONG Key);

NTSTATUS NTAPI NtReadFile(HANDLE FileHandle, HANDLE Event, PIO_APC_ROUTINE ApcRoutine, PVOID ApcContext, PIO_STATUS_BLOCK IoStatusBlock, PVOID Buffer,
                          ULONG Length, PLARGE_INTEGER ByteOffset, PULONG Key);
#ifdef __cplusplus
}
#endif

// These are undocumented, and what comes from format.exe
typedef struct {
    void* table;
    void* unk1;
    WCHAR* string;
} DSTRING;

typedef struct {
    void* table;
} STREAM_MESSAGE;

#define FORMAT_FLAG_QUICK_FORMAT        0x00000001
#define FORMAT_FLAG_UNKNOWN1            0x00000002
#define FORMAT_FLAG_DISMOUNT_FIRST      0x00000004
#define FORMAT_FLAG_UNKNOWN2            0x00000040
#define FORMAT_FLAG_LARGE_RECORDS       0x00000100
#define FORMAT_FLAG_INTEGRITY_DISABLE   0x00000100

typedef struct {
    uint16_t unk1;
    uint16_t unk2;
    uint32_t flags;
    DSTRING* label;
} options;

FORCEINLINE VOID InitializeListHead(PLIST_ENTRY ListHead) {
    ListHead->Flink = ListHead->Blink = ListHead;
}

FORCEINLINE VOID InsertTailList(PLIST_ENTRY ListHead, PLIST_ENTRY Entry) {
    PLIST_ENTRY Blink;

    Blink = ListHead->Blink;
    Entry->Flink = ListHead;
    Entry->Blink = Blink;
    Blink->Flink = Entry;
    ListHead->Blink = Entry;
}

typedef struct {
    struct btrfs_key key;
    uint16_t size;
    void* data;
    LIST_ENTRY list_entry;
} pending_item;

typedef struct {
    uint64_t address;
    uint64_t size;
    LIST_ENTRY list_entry;
} used_space_extent;

typedef struct {
    uint64_t offset;
    struct btrfs_chunk* chunk_item;
    uint64_t lastoff;
    uint64_t used;
    LIST_ENTRY used_space;
    LIST_ENTRY list_entry;
} btrfs_chunk;

typedef struct {
    uint64_t id;
    struct btrfs_header header;
    btrfs_chunk* c;
    LIST_ENTRY items;
    LIST_ENTRY list_entry;
} btrfs_root;

typedef struct {
    struct btrfs_dev_item dev_item;
    uint64_t last_alloc;
} btrfs_dev;

#define keycmp(key1, key2)\
    ((key1.objectid < key2.objectid) ? -1 :\
    ((key1.objectid > key2.objectid) ? 1 :\
    ((key1.type < key2.type) ? -1 :\
    ((key1.type > key2.type) ? 1 :\
    ((key1.offset < key2.offset) ? -1 :\
    ((key1.offset > key2.offset) ? 1 :\
    0))))))

HMODULE module;
ULONG def_sector_size = 0, def_node_size = 0;
uint64_t def_incompat_flags = BTRFS_FEATURE_INCOMPAT_EXTENDED_IREF | BTRFS_FEATURE_INCOMPAT_SKINNY_METADATA;
uint64_t def_compat_ro_flags = 0;
uint16_t def_csum_type = BTRFS_CSUM_TYPE_CRC32;

// the following definitions come from fmifs.h in ReactOS

typedef struct {
    ULONG Lines;
    PCHAR Output;
} TEXTOUTPUT, *PTEXTOUTPUT;

typedef enum {
    FMIFS_UNKNOWN0,
    FMIFS_UNKNOWN1,
    FMIFS_UNKNOWN2,
    FMIFS_UNKNOWN3,
    FMIFS_UNKNOWN4,
    FMIFS_UNKNOWN5,
    FMIFS_UNKNOWN6,
    FMIFS_UNKNOWN7,
    FMIFS_FLOPPY,
    FMIFS_UNKNOWN9,
    FMIFS_UNKNOWN10,
    FMIFS_REMOVABLE,
    FMIFS_HARDDISK,
    FMIFS_UNKNOWN13,
    FMIFS_UNKNOWN14,
    FMIFS_UNKNOWN15,
    FMIFS_UNKNOWN16,
    FMIFS_UNKNOWN17,
    FMIFS_UNKNOWN18,
    FMIFS_UNKNOWN19,
    FMIFS_UNKNOWN20,
    FMIFS_UNKNOWN21,
    FMIFS_UNKNOWN22,
    FMIFS_UNKNOWN23,
} FMIFS_MEDIA_FLAG;

typedef enum {
    PROGRESS,
    DONEWITHSTRUCTURE,
    UNKNOWN2,
    UNKNOWN3,
    UNKNOWN4,
    UNKNOWN5,
    INSUFFICIENTRIGHTS,
    FSNOTSUPPORTED,
    VOLUMEINUSE,
    UNKNOWN9,
    UNKNOWNA,
    DONE,
    UNKNOWNC,
    UNKNOWND,
    OUTPUT,
    STRUCTUREPROGRESS,
    CLUSTERSIZETOOSMALL,
} CALLBACKCOMMAND;

typedef BOOLEAN (NTAPI* PFMIFSCALLBACK)(CALLBACKCOMMAND Command, ULONG SubAction, PVOID ActionInfo);

static bool IsListEmpty(LIST_ENTRY* head) {
    return head->Flink == head;
}

static LIST_ENTRY* RemoveHeadList(LIST_ENTRY* head) {
    LIST_ENTRY *flink, *entry;

    entry = head->Flink;
    flink = entry->Flink;
    head->Flink = flink;
    flink->Blink = head;

    return entry;
}

NTSTATUS WINAPI ChkdskEx(PUNICODE_STRING DriveRoot, BOOLEAN FixErrors, BOOLEAN Verbose, BOOLEAN CheckOnlyIfDirty,
                         BOOLEAN ScanDrive, PFMIFSCALLBACK Callback) {
    // STUB

    if (Callback) {
        TEXTOUTPUT TextOut;

        TextOut.Lines = 1;
        TextOut.Output = "stub, not implemented";

        Callback(OUTPUT, 0, &TextOut);
    }

    return STATUS_SUCCESS;
}

static btrfs_root* add_root(LIST_ENTRY* roots, uint64_t id) {
    btrfs_root* root;

    root = malloc(sizeof(btrfs_root));

    root->id = id;
    RtlZeroMemory(&root->header, sizeof(struct btrfs_header));
    InitializeListHead(&root->items);
    InsertTailList(roots, &root->list_entry);

    return root;
}

static void free_roots(LIST_ENTRY* roots) {
    LIST_ENTRY* le;

    le = roots->Flink;
    while (le != roots) {
        LIST_ENTRY *le2 = le->Flink, *le3;
        btrfs_root* r = CONTAINING_RECORD(le, btrfs_root, list_entry);

        le3 = r->items.Flink;
        while (le3 != &r->items) {
            LIST_ENTRY* le4 = le3->Flink;
            pending_item* item = CONTAINING_RECORD(le3, pending_item, list_entry);

            if (item->data)
                free(item->data);

            free(item);

            le3 = le4;
        }

        free(r);

        le = le2;
    }
}

static void free_chunks(LIST_ENTRY* chunks) {
    LIST_ENTRY* le;

    le = chunks->Flink;
    while (le != chunks) {
        LIST_ENTRY *le2 = le->Flink;
        btrfs_chunk* c = CONTAINING_RECORD(le, btrfs_chunk, list_entry);

        while (!IsListEmpty(&c->used_space)) {
            used_space_extent* use = CONTAINING_RECORD(RemoveHeadList(&c->used_space), used_space_extent, list_entry);

            free(use);
        }

        free(c->chunk_item);
        free(c);

        le = le2;
    }
}

static void add_item(btrfs_root* r, uint64_t objectid, uint8_t type, uint64_t offset, void* data, uint16_t size) {
    LIST_ENTRY* le;
    pending_item* item;

    item = malloc(sizeof(pending_item));

    item->key.objectid = objectid;
    item->key.type = type;
    item->key.offset = offset;
    item->size = size;

    if (size == 0)
        item->data = NULL;
    else {
        item->data = malloc(size);
        memcpy(item->data, data, size);
    }

    le = r->items.Flink;
    while (le != &r->items) {
        pending_item* i2 = CONTAINING_RECORD(le, pending_item, list_entry);

        if (keycmp(item->key, i2->key) != 1) {
            InsertTailList(le, &item->list_entry);
            return;
        }

        le = le->Flink;
    }

    InsertTailList(&r->items, &item->list_entry);
}

static uint64_t find_chunk_offset(uint64_t size, uint64_t offset, btrfs_dev* dev,
                                  btrfs_root* dev_root, uint8_t* chunkuuid) {
    uint64_t off;
    struct btrfs_dev_extent de;

    off = dev->last_alloc;
    dev->last_alloc += size;

    dev->dev_item.bytes_used += size;

    de.chunk_tree = BTRFS_CHUNK_TREE_OBJECTID;
    de.chunk_objectid = 0x100;
    de.chunk_offset = offset;
    de.length = size;
    memcpy(de.chunk_tree_uuid, chunkuuid, BTRFS_UUID_SIZE);

    add_item(dev_root, dev->dev_item.devid, BTRFS_DEV_EXTENT_KEY, off, &de, sizeof(struct btrfs_dev_extent));

    return off;
}

static btrfs_chunk* add_chunk(LIST_ENTRY* chunks, uint64_t flags, btrfs_root* chunk_root,
                              btrfs_dev* dev, btrfs_root* dev_root, uint8_t* chunkuuid,
                              uint32_t sector_size) {
    uint64_t off, size;
    uint16_t stripes, i;
    btrfs_chunk* c;
    LIST_ENTRY* le;
    uint64_t stripe_length = max(sector_size, 0x10000);

    off = 0xc00000;
    le = chunks->Flink;
    while (le != chunks) {
        c = CONTAINING_RECORD(le, btrfs_chunk, list_entry);

        if (c->offset + c->chunk_item->length > off)
            off = c->offset + c->chunk_item->length;

        le = le->Flink;
    }

    if (flags & BTRFS_BLOCK_GROUP_METADATA) {
        if (dev->dev_item.total_bytes > 0xC80000000) // 50 GB
            size = 0x40000000; // 1 GB
        else
            size = 0x10000000; // 256 MB
    } else // BTRFS_BLOCK_GROUP_SYSTEM
        size = 0x800000;

    size = min(size, dev->dev_item.total_bytes / 10); // cap at 10%
    size &= ~(stripe_length - 1);

    stripes = flags & BTRFS_BLOCK_GROUP_DUP ? 2 : 1;

    if (dev->dev_item.total_bytes - dev->dev_item.bytes_used < stripes * size) // not enough space
        return NULL;

    c = malloc(sizeof(btrfs_chunk));
    c->offset = off;
    c->lastoff = off;
    c->used = 0;
    InitializeListHead(&c->used_space);

    c->chunk_item = malloc(offsetof(struct btrfs_chunk, stripe) + (stripes * sizeof(struct btrfs_stripe)));

    c->chunk_item->length = size;
    c->chunk_item->owner = BTRFS_EXTENT_TREE_OBJECTID;
    c->chunk_item->stripe_len = stripe_length;
    c->chunk_item->type = flags;
    c->chunk_item->io_align = stripe_length;
    c->chunk_item->io_width = stripe_length;
    c->chunk_item->sector_size = sector_size;
    c->chunk_item->num_stripes = stripes;
    c->chunk_item->sub_stripes = 0;

    for (i = 0; i < stripes; i++) {
        c->chunk_item->stripe[i].devid = dev->dev_item.devid;
        c->chunk_item->stripe[i].offset = find_chunk_offset(size, c->offset, dev, dev_root, chunkuuid);

        memcpy(c->chunk_item->stripe[i].dev_uuid, dev->dev_item.uuid,
               BTRFS_UUID_SIZE);
    }

    add_item(chunk_root, 0x100, BTRFS_CHUNK_ITEM_KEY, c->offset, c->chunk_item, offsetof(struct btrfs_chunk, stripe) + (stripes * sizeof(struct btrfs_stripe)));

    InsertTailList(chunks, &c->list_entry);

    return c;
}

static bool superblock_collision(btrfs_chunk* c, uint64_t address) {
    uint64_t stripe = (address - c->offset) / c->chunk_item->stripe_len;
    uint16_t i, j;

    for (i = 0; i < c->chunk_item->num_stripes; i++) {
        j = 0;
        while (superblock_addrs[j] != 0) {
            if (superblock_addrs[j] >= c->chunk_item->stripe[i].offset) {
                uint64_t stripe2 = (superblock_addrs[j] - c->chunk_item->stripe[i].offset) / c->chunk_item->stripe_len;

                if (stripe2 == stripe)
                    return true;
            }
            j++;
        }
    }

    return false;
}

static uint64_t get_next_address(btrfs_chunk* c) {
    uint64_t addr;

    addr = c->lastoff;

    while (superblock_collision(c, addr)) {
        addr = addr - ((addr - c->offset) % c->chunk_item->stripe_len) + c->chunk_item->stripe_len;

        if (addr >= c->offset + c->chunk_item->length) // chunk has been exhausted
            return 0;
    }

    return addr;
}

typedef struct {
    struct btrfs_extent_item ei;
    struct btrfs_extent_inline_ref eir;
} EXTENT_ITEM_METADATA;

static_assert(sizeof(EXTENT_ITEM_METADATA) == 33, "EXTENT_ITEM_METADATA has wrong size");

typedef struct {
    struct btrfs_extent_item ei;
    struct btrfs_tree_block_info ei2;
    struct btrfs_extent_inline_ref eir;
} EXTENT_ITEM_METADATA2;

static_assert(sizeof(EXTENT_ITEM_METADATA2) == 51, "EXTENT_ITEM_METADATA2 has wrong size");

static void assign_addresses(LIST_ENTRY* roots, btrfs_chunk* sys_chunk, btrfs_chunk* metadata_chunk, uint32_t node_size,
                             btrfs_root* root_root, btrfs_root* extent_root, bool skinny) {
    LIST_ENTRY* le;

    le = roots->Flink;
    while (le != roots) {
        btrfs_root* r = CONTAINING_RECORD(le, btrfs_root, list_entry);
        btrfs_chunk* c = r->id == BTRFS_CHUNK_TREE_OBJECTID ? sys_chunk : metadata_chunk;
        bool done_use = false;

        r->header.bytenr = get_next_address(c);

        if (!IsListEmpty(&c->used_space)) {
            used_space_extent* use = CONTAINING_RECORD(c->used_space.Blink, used_space_extent, list_entry);

            if (use->address + use->size == r->header.bytenr) {
                use->size += node_size;
                done_use = true;
            }
        }

        if (!done_use) {
            used_space_extent* use = malloc(sizeof(used_space_extent));
            use->address = r->header.bytenr;
            use->size = node_size;
            InsertTailList(&c->used_space, &use->list_entry);
        }

        r->c = c;
        c->lastoff = r->header.bytenr + node_size;
        c->used += node_size;

        if (skinny) {
            EXTENT_ITEM_METADATA eim;

            eim.ei.refs = 1;
            eim.ei.generation = 1;
            eim.ei.flags = BTRFS_EXTENT_FLAG_TREE_BLOCK;
            eim.eir.type = BTRFS_TREE_BLOCK_REF_KEY;
            eim.eir.offset = r->id;

            add_item(extent_root, r->header.bytenr, BTRFS_METADATA_ITEM_KEY, 0, &eim, sizeof(EXTENT_ITEM_METADATA));
        } else {
            EXTENT_ITEM_METADATA2 eim2;
            struct btrfs_key firstitem;

            if (r->items.Flink == &r->items) {
                firstitem.objectid = 0;
                firstitem.type = 0;
                firstitem.offset = 0;
            } else {
                pending_item* bi = CONTAINING_RECORD(r->items.Flink, pending_item, list_entry);

                firstitem = bi->key;
            }

            eim2.ei.refs = 1;
            eim2.ei.generation = 1;
            eim2.ei.flags = BTRFS_EXTENT_FLAG_TREE_BLOCK;
            eim2.ei2.key = firstitem;
            eim2.ei2.level = 0;
            eim2.eir.type = BTRFS_TREE_BLOCK_REF_KEY;
            eim2.eir.offset = r->id;

            add_item(extent_root, r->header.bytenr, BTRFS_EXTENT_ITEM_KEY, node_size, &eim2, sizeof(EXTENT_ITEM_METADATA2));
        }

        if (r->id != BTRFS_ROOT_TREE_OBJECTID && r->id != BTRFS_CHUNK_TREE_OBJECTID) {
            struct btrfs_root_item ri;

            memset(&ri, 0, sizeof(struct btrfs_root_item));

            ri.inode.generation = 1;
            ri.inode.size = 3;
            ri.inode.nbytes = node_size;
            ri.inode.nlink = 1;
            ri.inode.mode = 040755;
            ri.generation = 1;
            ri.root_dirid = r->id == 5 || r->id >= 0x100 ? BTRFS_FIRST_FREE_OBJECTID : 0;
            ri.bytenr = r->header.bytenr;
            ri.bytes_used = node_size;
            ri.refs = 1;
            ri.generation_v2 = ri.generation;

            add_item(root_root, r->id, BTRFS_ROOT_ITEM_KEY, 0, &ri, sizeof(struct btrfs_root_item));
        }

        le = le->Flink;
    }
}

static NTSTATUS write_data(HANDLE h, uint64_t address, btrfs_chunk* c, void* data, ULONG size) {
    NTSTATUS Status;
    uint16_t i;
    IO_STATUS_BLOCK iosb;
    LARGE_INTEGER off;

    for (i = 0; i < c->chunk_item->num_stripes; i++) {
        off.QuadPart = c->chunk_item->stripe[i].offset + address - c->offset;

        Status = NtWriteFile(h, NULL, NULL, NULL, &iosb, data, size, &off, NULL);
        if (!NT_SUCCESS(Status))
            return Status;
    }

    return STATUS_SUCCESS;
}

static void calc_tree_checksum(struct btrfs_header* th, uint32_t node_size) {
    switch (def_csum_type) {
        case BTRFS_CSUM_TYPE_CRC32:
            *(uint32_t*)th = ~calc_crc32c(0xffffffff, (uint8_t*)&th->fsid, node_size - sizeof(th->csum));
        break;

        case BTRFS_CSUM_TYPE_XXHASH:
            *(uint64_t*)th = XXH64((uint8_t*)&th->fsid, node_size - sizeof(th->csum), 0);
        break;

        case BTRFS_CSUM_TYPE_SHA256:
            calc_sha256((uint8_t*)th, &th->fsid, node_size - sizeof(th->csum));
        break;

        case BTRFS_CSUM_TYPE_BLAKE2:
            blake2b((uint8_t*)th, BLAKE2_HASH_SIZE, &th->fsid, node_size - sizeof(th->csum));
        break;
    }
}

static NTSTATUS write_roots(HANDLE h, LIST_ENTRY* roots, uint32_t node_size,
                            uint8_t* fsuuid, uint8_t* chunkuuid) {
    LIST_ENTRY *le, *le2;
    NTSTATUS Status;
    uint8_t* tree;

    tree = malloc(node_size);

    le = roots->Flink;
    while (le != roots) {
        btrfs_root* r = CONTAINING_RECORD(le, btrfs_root, list_entry);
        uint8_t* dp;
        struct btrfs_item* ln;

        memset(tree, 0, node_size);

        r->header.nritems = 0;
        memcpy(r->header.fsid, fsuuid, BTRFS_UUID_SIZE);
        r->header.flags = (BTRFS_MIXED_BACKREF_REV << BTRFS_BACKREF_REV_SHIFT) | BTRFS_HEADER_FLAG_WRITTEN;
        memcpy(r->header.chunk_tree_uuid, chunkuuid, BTRFS_UUID_SIZE);
        r->header.generation = 1;
        r->header.owner = r->id;

        ln = (struct btrfs_item*)(tree + sizeof(struct btrfs_header));

        dp = tree + node_size;

        le2 = r->items.Flink;
        while (le2 != &r->items) {
            pending_item* item = CONTAINING_RECORD(le2, pending_item, list_entry);

            ln->key = item->key;
            ln->size = item->size;

            if (item->size > 0) {
                dp -= item->size;
                memcpy(dp, item->data, item->size);
            }

            ln->offset = (uint32_t)(dp - tree - sizeof(struct btrfs_header));

            ln = &ln[1];

            r->header.nritems++;

            le2 = le2->Flink;
        }

        memcpy(tree, &r->header, sizeof(struct btrfs_header));

        calc_tree_checksum((struct btrfs_header*)tree, node_size);

        Status = write_data(h, r->header.bytenr, r->c, tree, node_size);
        if (!NT_SUCCESS(Status)) {
            free(tree);
            return Status;
        }

        le = le->Flink;
    }

    free(tree);

    return STATUS_SUCCESS;
}

static void get_uuid(uint8_t* uuid) {
    uint8_t i;

    for (i = 0; i < BTRFS_UUID_SIZE; i += 2) {
        ULONG r = rand();

        uuid[i] = (r & 0xff00) >> 8;
        uuid[i + 1] = r & 0xff;
    }
}

static void init_device(btrfs_dev* dev, uint64_t id, uint64_t size, uint8_t* fsuuid,
                        uint32_t sector_size) {
    dev->dev_item.devid = id;
    dev->dev_item.total_bytes = size;
    dev->dev_item.bytes_used = 0;
    dev->dev_item.io_align = sector_size;
    dev->dev_item.io_width = sector_size;
    dev->dev_item.sector_size = sector_size;
    dev->dev_item.type = 0;
    dev->dev_item.generation = 0;
    dev->dev_item.start_offset = 0;
    dev->dev_item.dev_group = 0;
    dev->dev_item.seek_speed = 0;
    dev->dev_item.bandwidth = 0;
    get_uuid(dev->dev_item.uuid);
    memcpy(dev->dev_item.fsid, fsuuid, BTRFS_UUID_SIZE);

    dev->last_alloc = 0x100000; // skip first megabyte
}

static void calc_superblock_checksum(struct btrfs_super_block* sb) {
    switch (def_csum_type) {
        case BTRFS_CSUM_TYPE_CRC32:
            *(uint32_t*)sb = ~calc_crc32c(0xffffffff, (uint8_t*)&sb->fsid, (ULONG)sizeof(struct btrfs_super_block) - sizeof(sb->csum));
        break;

        case BTRFS_CSUM_TYPE_XXHASH:
            *(uint64_t*)sb = XXH64(&sb->fsid, sizeof(struct btrfs_super_block) - sizeof(sb->csum), 0);
        break;

        case BTRFS_CSUM_TYPE_SHA256:
            calc_sha256((uint8_t*)sb, &sb->fsid, sizeof(struct btrfs_super_block) - sizeof(sb->csum));
        break;

        case BTRFS_CSUM_TYPE_BLAKE2:
            blake2b((uint8_t*)sb, BLAKE2_HASH_SIZE, &sb->fsid, sizeof(struct btrfs_super_block) - sizeof(sb->csum));
        break;
    }
}

static NTSTATUS write_superblocks(HANDLE h, btrfs_dev* dev, btrfs_root* chunk_root, btrfs_root* root_root, btrfs_root* extent_root,
                                  btrfs_chunk* sys_chunk, uint32_t node_size, uint8_t* fsuuid, uint32_t sector_size, PUNICODE_STRING label,
                                  uint64_t incompat_flags, uint64_t compat_ro_flags) {
    NTSTATUS Status;
    IO_STATUS_BLOCK iosb;
    ULONG sblen;
    int i;
    struct btrfs_super_block* sb;
    struct btrfs_key* key;
    uint64_t bytes_used;
    LIST_ENTRY* le;

    sblen = sizeof(*sb);
    if (sblen & (sector_size - 1))
        sblen = (sblen & sector_size) + sector_size;

    bytes_used = 0;

    le = extent_root->items.Flink;
    while (le != &extent_root->items) {
        pending_item* item = CONTAINING_RECORD(le, pending_item, list_entry);

        if (item->key.type == BTRFS_EXTENT_ITEM_KEY)
            bytes_used += item->key.offset;
        else if (item->key.type == BTRFS_METADATA_ITEM_KEY)
            bytes_used += node_size;

        le = le->Flink;
    }

    sb = malloc(sblen);
    memset(sb, 0, sblen);

    memcpy(sb->fsid, fsuuid, BTRFS_UUID_SIZE);
    sb->flags = 1;
    sb->magic = BTRFS_MAGIC;
    sb->generation = 1;
    sb->root = root_root->header.bytenr;
    sb->chunk_root = chunk_root->header.bytenr;
    sb->total_bytes = dev->dev_item.total_bytes;
    sb->bytes_used = bytes_used;
    sb->root_dir_objectid = BTRFS_ROOT_TREE_DIR_OBJECTID;
    sb->num_devices = 1;
    sb->sectorsize = sector_size;
    sb->nodesize = node_size;
    sb->__unused_leafsize = node_size;
    sb->stripesize = sector_size;
    sb->sys_chunk_array_size = sizeof(struct btrfs_key) + offsetof(struct btrfs_chunk, stripe) + (sys_chunk->chunk_item->num_stripes * sizeof(struct btrfs_stripe));
    sb->chunk_root_generation = 1;
    sb->compat_ro_flags = compat_ro_flags;
    sb->incompat_flags = incompat_flags;
    sb->csum_type = def_csum_type;
    memcpy(&sb->dev_item, &dev->dev_item, sizeof(struct btrfs_dev_item));

    if (label->Length > 0) {
        ULONG utf8len;

        for (unsigned int i = 0; i < label->Length / sizeof(WCHAR); i++) {
            if (label->Buffer[i] == '/' || label->Buffer[i] == '\\') {
                free(sb);
                return STATUS_INVALID_VOLUME_LABEL;
            }
        }

        utf8len = WideCharToMultiByte(CP_UTF8, 0, label->Buffer, label->Length / sizeof(WCHAR), NULL, 0, NULL, NULL);

        if (utf8len == 0 || utf8len > BTRFS_LABEL_SIZE) {
            free(sb);
            return STATUS_INVALID_VOLUME_LABEL;
        }

        if (WideCharToMultiByte(CP_UTF8, 0, label->Buffer, label->Length / sizeof(WCHAR), sb->label, utf8len, NULL, NULL) == 0) {
            free(sb);
            return STATUS_INVALID_VOLUME_LABEL;
        }
    }
    sb->cache_generation = 0xffffffffffffffff;

    key = (struct btrfs_key*)sb->sys_chunk_array;
    key->objectid = 0x100;
    key->type = BTRFS_CHUNK_ITEM_KEY;
    key->offset = sys_chunk->offset;
    memcpy(&key[1], sys_chunk->chunk_item, offsetof(struct btrfs_chunk, stripe) + (sys_chunk->chunk_item->num_stripes * sizeof(struct btrfs_stripe)));

    i = 0;
    while (superblock_addrs[i] != 0) {
        LARGE_INTEGER off;

        if (superblock_addrs[i] > dev->dev_item.total_bytes)
            break;

        sb->bytenr = superblock_addrs[i];

        calc_superblock_checksum(sb);

        off.QuadPart = superblock_addrs[i];

        Status = NtWriteFile(h, NULL, NULL, NULL, &iosb, sb, sblen, &off, NULL);
        if (!NT_SUCCESS(Status)) {
            free(sb);
            return Status;
        }

        i++;
    }

    free(sb);

    return STATUS_SUCCESS;
}

static __inline void win_time_to_unix(LARGE_INTEGER t, struct btrfs_timespec* out) {
    ULONGLONG l = t.QuadPart - 116444736000000000;

    out->sec = l / 10000000;
    out->nsec = (l % 10000000) * 100;
}

static void add_inode_ref(btrfs_root* r, uint64_t inode, uint64_t parent, uint64_t index, const char* name) {
    uint16_t name_len = (uint16_t)strlen(name);
    struct btrfs_inode_ref* ir = malloc(sizeof(struct btrfs_inode_ref) + name_len);

    ir->index = 0;
    ir->name_len = name_len;
    memcpy(&ir[1], name, name_len);

    add_item(r, inode, BTRFS_INODE_REF_KEY, parent, ir, (uint16_t)sizeof(struct btrfs_inode_ref) + ir->name_len);

    free(ir);
}

static void init_fs_tree(btrfs_root* r, uint32_t node_size) {
    struct btrfs_inode_item ii;
    FILETIME filetime;
    LARGE_INTEGER time;

    memset(&ii, 0, sizeof(struct btrfs_inode_item));

    ii.generation = 1;
    ii.nbytes = node_size;
    ii.nlink = 1;
    ii.mode = 040755;

    GetSystemTimeAsFileTime(&filetime);
    time.LowPart = filetime.dwLowDateTime;
    time.HighPart = filetime.dwHighDateTime;

    win_time_to_unix(time, &ii.atime);
    ii.ctime = ii.mtime = ii.atime;

    add_item(r, BTRFS_FIRST_FREE_OBJECTID, BTRFS_INODE_ITEM_KEY, 0, &ii, sizeof(struct btrfs_inode_item));

    add_inode_ref(r, BTRFS_FIRST_FREE_OBJECTID, BTRFS_FIRST_FREE_OBJECTID, 0, "..");
}

static void add_block_group_items(LIST_ENTRY* chunks, btrfs_root* root) {
    LIST_ENTRY* le;

    le = chunks->Flink;
    while (le != chunks) {
        btrfs_chunk* c = CONTAINING_RECORD(le, btrfs_chunk, list_entry);
        struct btrfs_block_group_item bgi;

        bgi.used = c->used;
        bgi.chunk_objectid = 0x100;
        bgi.flags = c->chunk_item->type;
        add_item(root, c->offset, BTRFS_BLOCK_GROUP_ITEM_KEY, c->chunk_item->length, &bgi, sizeof(struct btrfs_block_group_item));

        le = le->Flink;
    }
}

static NTSTATUS clear_first_megabyte(HANDLE h) {
    NTSTATUS Status;
    IO_STATUS_BLOCK iosb;
    LARGE_INTEGER zero;
    uint8_t* mb;

    mb = malloc(0x100000);
    memset(mb, 0, 0x100000);

    zero.QuadPart = 0;

    Status = NtWriteFile(h, NULL, NULL, NULL, &iosb, mb, 0x100000, &zero, NULL);

    free(mb);

    return Status;
}

static bool is_ssd(HANDLE h) {
    ULONG aptelen;
    ATA_PASS_THROUGH_EX* apte;
    IO_STATUS_BLOCK iosb;
    NTSTATUS Status;
    IDENTIFY_DEVICE_DATA* idd;

    aptelen = sizeof(ATA_PASS_THROUGH_EX) + 512;
    apte = malloc(aptelen);

    RtlZeroMemory(apte, aptelen);

    apte->Length = sizeof(ATA_PASS_THROUGH_EX);
    apte->AtaFlags = ATA_FLAGS_DATA_IN;
    apte->DataTransferLength = aptelen - sizeof(ATA_PASS_THROUGH_EX);
    apte->TimeOutValue = 3;
    apte->DataBufferOffset = apte->Length;
    apte->CurrentTaskFile[6] = IDE_COMMAND_IDENTIFY;

    Status = NtDeviceIoControlFile(h, NULL, NULL, NULL, &iosb, IOCTL_ATA_PASS_THROUGH, apte, aptelen, apte, aptelen);

    if (NT_SUCCESS(Status)) {
        idd = (IDENTIFY_DEVICE_DATA*)((uint8_t*)apte + sizeof(ATA_PASS_THROUGH_EX));

        if (idd->NominalMediaRotationRate == 1) {
            free(apte);
            return true;
        }
    }

    free(apte);

    return false;
}

static void add_dir_item(btrfs_root* root, uint64_t inode, uint32_t hash, uint64_t key_objid, uint8_t key_type,
                         uint64_t key_offset, uint64_t transid, uint8_t type, const char* name) {
    uint16_t name_len = (uint16_t)strlen(name);
    struct btrfs_dir_item* di = malloc(sizeof(struct btrfs_dir_item) + name_len);

    di->location.objectid = key_objid;
    di->location.type = key_type;
    di->location.offset = key_offset;
    di->transid = transid;
    di->data_len = 0;
    di->name_len = name_len;
    di->type = type;
    memcpy(&di[1], name, name_len);

    add_item(root, inode, BTRFS_DIR_ITEM_KEY, hash, di, (uint16_t)(sizeof(struct btrfs_dir_item) + di->data_len + di->name_len));

    free(di);
}

static void set_default_subvol(btrfs_root* root_root, uint32_t node_size) {
    struct btrfs_inode_item ii;
    FILETIME filetime;
    LARGE_INTEGER time;

    static const char default_subvol[] = "default";
    static const uint32_t default_hash = 0x8dbfc2d2;

    add_inode_ref(root_root, BTRFS_FS_TREE_OBJECTID, BTRFS_ROOT_TREE_DIR_OBJECTID, 0, default_subvol);

    memset(&ii, 0, sizeof(struct btrfs_inode_item));

    ii.generation = 1;
    ii.nbytes = node_size;
    ii.nlink = 1;
    ii.mode = 040755;

    GetSystemTimeAsFileTime(&filetime);
    time.LowPart = filetime.dwLowDateTime;
    time.HighPart = filetime.dwHighDateTime;

    win_time_to_unix(time, &ii.atime);
    ii.ctime = ii.mtime = ii.otime = ii.atime;

    add_item(root_root, BTRFS_ROOT_TREE_DIR_OBJECTID, BTRFS_INODE_ITEM_KEY, 0, &ii, sizeof(struct btrfs_inode_item));

    add_inode_ref(root_root, BTRFS_ROOT_TREE_DIR_OBJECTID, BTRFS_ROOT_TREE_DIR_OBJECTID, 0, "..");

    add_dir_item(root_root, BTRFS_ROOT_TREE_DIR_OBJECTID, default_hash, BTRFS_FS_TREE_OBJECTID, BTRFS_ROOT_ITEM_KEY,
                 0xffffffffffffffff, 0, BTRFS_FT_DIR, default_subvol);
}

static void populate_free_space_root(LIST_ENTRY* chunks, btrfs_root* free_space_root) {
    LIST_ENTRY* le;

    le = chunks->Flink;
    while (le != chunks) {
        btrfs_chunk* c = CONTAINING_RECORD(le, btrfs_chunk, list_entry);
        uint64_t last_end = c->offset;
        LIST_ENTRY* le2;
        struct btrfs_free_space_info fsi;

        fsi.extent_count = 0;
        fsi.flags = 0;

        le2 = c->used_space.Flink;
        while (le2 != &c->used_space) {
            used_space_extent* use = CONTAINING_RECORD(le2, used_space_extent, list_entry);

            if (use->address > last_end) {
                add_item(free_space_root, last_end, BTRFS_FREE_SPACE_EXTENT_KEY, use->address - last_end,
                         NULL, 0);
                fsi.extent_count++;
            }

            last_end = use->address + use->size;

            le2 = le2->Flink;
        }

        if (c->offset + c->chunk_item->length > last_end) {
            add_item(free_space_root, last_end, BTRFS_FREE_SPACE_EXTENT_KEY, c->offset + c->chunk_item->length - last_end,
                     NULL, 0);
            fsi.extent_count++;
        }

        add_item(free_space_root, c->offset, BTRFS_FREE_SPACE_INFO_KEY, c->chunk_item->length, &fsi, sizeof(fsi));

        le = le->Flink;
    }
}

static NTSTATUS write_btrfs(HANDLE h, uint64_t size, PUNICODE_STRING label, uint32_t sector_size, uint32_t node_size, uint64_t incompat_flags,
                            uint64_t compat_ro_flags) {
    NTSTATUS Status;
    LIST_ENTRY roots, chunks;
    btrfs_root *root_root, *chunk_root, *extent_root, *dev_root, *fs_root, *reloc_root,
               *block_group_root, *free_space_root;
    btrfs_chunk *sys_chunk, *metadata_chunk;
    btrfs_dev dev;
    uint8_t fsuuid[BTRFS_UUID_SIZE], chunkuuid[BTRFS_UUID_SIZE];
    bool ssd;
    uint64_t metadata_flags;

    srand((unsigned int)time(0));
    get_uuid(fsuuid);
    get_uuid(chunkuuid);

    InitializeListHead(&roots);
    InitializeListHead(&chunks);

    root_root = add_root(&roots, BTRFS_ROOT_TREE_OBJECTID);
    chunk_root = add_root(&roots, BTRFS_CHUNK_TREE_OBJECTID);
    extent_root = add_root(&roots, BTRFS_EXTENT_TREE_OBJECTID);
    dev_root = add_root(&roots, BTRFS_DEV_TREE_OBJECTID);
    add_root(&roots, BTRFS_CSUM_TREE_OBJECTID);
    fs_root = add_root(&roots, BTRFS_FS_TREE_OBJECTID);
    reloc_root = add_root(&roots, BTRFS_DATA_RELOC_TREE_OBJECTID);

    if (compat_ro_flags & BTRFS_FEATURE_COMPAT_RO_FREE_SPACE_TREE)
        free_space_root = add_root(&roots, BTRFS_FREE_SPACE_TREE_OBJECTID);
    else
        free_space_root = NULL;

    if (compat_ro_flags & BTRFS_FEATURE_COMPAT_RO_BLOCK_GROUP_TREE)
        block_group_root = add_root(&roots, BTRFS_BLOCK_GROUP_TREE_OBJECTID);
    else
        block_group_root = NULL;

    init_device(&dev, 1, size, fsuuid, sector_size);

    ssd = is_ssd(h);

    sys_chunk = add_chunk(&chunks, BTRFS_BLOCK_GROUP_SYSTEM | (ssd ? 0 : BTRFS_BLOCK_GROUP_DUP),
                          chunk_root, &dev, dev_root, chunkuuid, sector_size);
    if (!sys_chunk)
        return STATUS_INTERNAL_ERROR;

    metadata_flags = BTRFS_BLOCK_GROUP_METADATA;

    if (!ssd && !(incompat_flags & BTRFS_FEATURE_INCOMPAT_MIXED_GROUPS))
        metadata_flags |= BTRFS_BLOCK_GROUP_DUP;

    if (incompat_flags & BTRFS_FEATURE_INCOMPAT_MIXED_GROUPS)
        metadata_flags |= BTRFS_BLOCK_GROUP_DATA;

    metadata_chunk = add_chunk(&chunks, metadata_flags, chunk_root, &dev, dev_root,
                               chunkuuid, sector_size);
    if (!metadata_chunk)
        return STATUS_INTERNAL_ERROR;

    add_item(chunk_root, 1, BTRFS_DEV_ITEM_KEY, dev.dev_item.devid, &dev.dev_item, sizeof(struct btrfs_dev_item));

    set_default_subvol(root_root, node_size);

    init_fs_tree(fs_root, node_size);
    init_fs_tree(reloc_root, node_size);

    assign_addresses(&roots, sys_chunk, metadata_chunk, node_size, root_root, extent_root, incompat_flags & BTRFS_FEATURE_INCOMPAT_SKINNY_METADATA);

    add_block_group_items(&chunks, block_group_root ? block_group_root : extent_root);

    if (free_space_root)
        populate_free_space_root(&chunks, free_space_root);

    Status = write_roots(h, &roots, node_size, fsuuid, chunkuuid);
    if (!NT_SUCCESS(Status))
        return Status;

    Status = clear_first_megabyte(h);
    if (!NT_SUCCESS(Status))
        return Status;

    Status = write_superblocks(h, &dev, chunk_root, root_root, extent_root, sys_chunk,
                               node_size, fsuuid, sector_size, label,
                               incompat_flags, compat_ro_flags);
    if (!NT_SUCCESS(Status))
        return Status;

    free_roots(&roots);
    free_chunks(&chunks);

    return STATUS_SUCCESS;
}

static bool look_for_device(btrfs_filesystem* bfs, uint8_t* devuuid) {
    uint32_t i;
    btrfs_filesystem_device* dev;

    for (i = 0; i < bfs->num_devices; i++) {
        if (i == 0)
            dev = &bfs->device;
        else
            dev = (btrfs_filesystem_device*)((uint8_t*)dev + offsetof(btrfs_filesystem_device, name[0]) + dev->name_length);

        if (RtlCompareMemory(&dev->uuid, devuuid, BTRFS_UUID_SIZE) == BTRFS_UUID_SIZE)
            return true;
    }

    return false;
}

static bool check_superblock_checksum(struct btrfs_super_block* sb) {
    switch (sb->csum_type) {
        case BTRFS_CSUM_TYPE_CRC32: {
            uint32_t crc32 = ~calc_crc32c(0xffffffff, (uint8_t*)&sb->fsid, (ULONG)sizeof(struct btrfs_super_block) - sizeof(sb->csum));

            return crc32 == *(uint32_t*)sb;
        }

        case BTRFS_CSUM_TYPE_XXHASH: {
            uint64_t hash = XXH64(&sb->fsid, sizeof(struct btrfs_super_block) - sizeof(sb->csum), 0);

            return hash == *(uint64_t*)sb;
        }

        case BTRFS_CSUM_TYPE_SHA256: {
            uint8_t hash[SHA256_HASH_SIZE];

            calc_sha256(hash, &sb->fsid, sizeof(struct btrfs_super_block) - sizeof(sb->csum));

            return !memcmp(hash, sb, SHA256_HASH_SIZE);
        }

        case BTRFS_CSUM_TYPE_BLAKE2: {
            uint8_t hash[BLAKE2_HASH_SIZE];

            blake2b(hash, sizeof(hash), &sb->fsid, sizeof(struct btrfs_super_block) - sizeof(sb->csum));

            return !memcmp(hash, sb, BLAKE2_HASH_SIZE);
        }

        default:
            return false;
    }
}

static bool is_mounted_multi_device(HANDLE h, uint32_t sector_size) {
    NTSTATUS Status;
    struct btrfs_super_block* sb;
    ULONG sblen;
    IO_STATUS_BLOCK iosb;
    LARGE_INTEGER off;
    uint8_t fsuuid[BTRFS_UUID_SIZE], devuuid[BTRFS_UUID_SIZE];
    UNICODE_STRING us;
    OBJECT_ATTRIBUTES atts;
    HANDLE h2;
    btrfs_filesystem *bfs = NULL, *bfs2;
    ULONG bfssize;
    bool ret = false;

    static WCHAR btrfs[] = L"\\Btrfs";

    sblen = sizeof(*sb);
    if (sblen & (sector_size - 1))
        sblen = (sblen & sector_size) + sector_size;

    sb = malloc(sblen);

    off.QuadPart = superblock_addrs[0];

    Status = NtReadFile(h, NULL, NULL, NULL, &iosb, sb, sblen, &off, NULL);
    if (!NT_SUCCESS(Status)) {
        free(sb);
        return false;
    }

    if (sb->magic != BTRFS_MAGIC) {
        free(sb);
        return false;
    }

    if (!check_superblock_checksum(sb)) {
        free(sb);
        return false;
    }

    memcpy(fsuuid, sb->fsid, BTRFS_UUID_SIZE);
    memcpy(devuuid, sb->dev_item.uuid, BTRFS_UUID_SIZE);

    free(sb);

    us.Length = us.MaximumLength = (USHORT)(wcslen(btrfs) * sizeof(WCHAR));
    us.Buffer = btrfs;

    InitializeObjectAttributes(&atts, &us, 0, NULL, NULL);

    Status = NtOpenFile(&h2, SYNCHRONIZE | FILE_READ_ATTRIBUTES, &atts, &iosb,
                        FILE_SHARE_READ | FILE_SHARE_WRITE, FILE_SYNCHRONOUS_IO_ALERT);
    if (!NT_SUCCESS(Status)) // not a problem, it usually just means the driver isn't loaded
        return false;

    bfssize = 0;

    do {
        bfssize += 1024;

        if (bfs) free(bfs);
        bfs = malloc(bfssize);

        Status = NtDeviceIoControlFile(h2, NULL, NULL, NULL, &iosb, IOCTL_BTRFS_QUERY_FILESYSTEMS, NULL, 0, bfs, bfssize);
    } while (Status == STATUS_BUFFER_OVERFLOW);

    if (!NT_SUCCESS(Status))
        goto end;

    if (bfs->num_devices != 0) {
        bfs2 = bfs;
        while (true) {
            if (RtlCompareMemory(&bfs2->uuid, &fsuuid, BTRFS_UUID_SIZE) == BTRFS_UUID_SIZE) {
                if (bfs2->num_devices == 1)
                    ret = false;
                else
                    ret = look_for_device(bfs2, devuuid);

                goto end;
            }

            if (bfs2->next_entry == 0)
                break;
            else
                bfs2 = (btrfs_filesystem*)((uint8_t*)bfs2 + bfs2->next_entry);
        }
    }

end:
    NtClose(h2);

    if (bfs)
        free(bfs);

    return ret;
}

static void do_full_trim(HANDLE h) {
    IO_STATUS_BLOCK iosb;
    DEVICE_MANAGE_DATA_SET_ATTRIBUTES dmdsa;

    RtlZeroMemory(&dmdsa, sizeof(DEVICE_MANAGE_DATA_SET_ATTRIBUTES));

    dmdsa.Size = sizeof(DEVICE_MANAGE_DATA_SET_ATTRIBUTES);
    dmdsa.Action = DeviceDsmAction_Trim;
    dmdsa.Flags = DEVICE_DSM_FLAG_ENTIRE_DATA_SET_RANGE | DEVICE_DSM_FLAG_TRIM_NOT_FS_ALLOCATED;
    dmdsa.ParameterBlockOffset = 0;
    dmdsa.ParameterBlockLength = 0;
    dmdsa.DataSetRangesOffset = 0;
    dmdsa.DataSetRangesLength = 0;

    NtDeviceIoControlFile(h, NULL, NULL, NULL, &iosb, IOCTL_STORAGE_MANAGE_DATA_SET_ATTRIBUTES, &dmdsa, sizeof(DEVICE_MANAGE_DATA_SET_ATTRIBUTES), NULL, 0);
}

static bool is_power_of_two(ULONG i) {
    return ((i != 0) && !(i & (i - 1)));
}

#if defined(_X86_) || defined(_AMD64_)
static void check_cpu() {
    unsigned int cpuInfo[4];
    bool have_sse42;

#ifndef _MSC_VER
    __get_cpuid(1, &cpuInfo[0], &cpuInfo[1], &cpuInfo[2], &cpuInfo[3]);
    have_sse42 = cpuInfo[2] & bit_SSE4_2;
#else
    __cpuid(cpuInfo, 1);
    have_sse42 = cpuInfo[2] & (1 << 20);
#endif

    if (have_sse42)
        calc_crc32c = calc_crc32c_hw;
}
#endif

static NTSTATUS NTAPI FormatEx2(PUNICODE_STRING DriveRoot, FMIFS_MEDIA_FLAG MediaFlag, PUNICODE_STRING Label,
                                BOOLEAN QuickFormat, ULONG ClusterSize, PFMIFSCALLBACK Callback)
{
    NTSTATUS Status;
    HANDLE h, btrfsh;
    OBJECT_ATTRIBUTES attr;
    IO_STATUS_BLOCK iosb;
    GET_LENGTH_INFORMATION gli;
    DISK_GEOMETRY dg;
    uint32_t sector_size, node_size;
    UNICODE_STRING btrfsus;
    HANDLE token;
    TOKEN_PRIVILEGES tp;
    LUID luid;
    uint64_t incompat_flags, compat_ro_flags;
    UNICODE_STRING empty_label;

    static WCHAR btrfs[] = L"\\Btrfs";

    if (!OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &token))
        return STATUS_PRIVILEGE_NOT_HELD;

    if (!LookupPrivilegeValueW(NULL, L"SeManageVolumePrivilege", &luid)) {
        CloseHandle(token);
        return STATUS_PRIVILEGE_NOT_HELD;
    }

    tp.PrivilegeCount = 1;
    tp.Privileges[0].Luid = luid;
    tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

    if (!AdjustTokenPrivileges(token, false, &tp, sizeof(TOKEN_PRIVILEGES), NULL, NULL)) {
        CloseHandle(token);
        return STATUS_PRIVILEGE_NOT_HELD;
    }

    CloseHandle(token);

#if defined(_X86_) || defined(_AMD64_)
    check_cpu();
#endif

    if (def_csum_type != BTRFS_CSUM_TYPE_CRC32 && def_csum_type != BTRFS_CSUM_TYPE_XXHASH && def_csum_type != BTRFS_CSUM_TYPE_SHA256 &&
        def_csum_type != BTRFS_CSUM_TYPE_BLAKE2)
        return STATUS_INVALID_PARAMETER;

    InitializeObjectAttributes(&attr, DriveRoot, OBJ_CASE_INSENSITIVE, NULL, NULL);

    Status = NtOpenFile(&h, FILE_GENERIC_READ | FILE_GENERIC_WRITE, &attr, &iosb,
                        FILE_SHARE_READ, FILE_SYNCHRONOUS_IO_ALERT);

    if (!NT_SUCCESS(Status))
        return Status;

    Status = NtDeviceIoControlFile(h, NULL, NULL, NULL, &iosb, IOCTL_DISK_GET_LENGTH_INFO, NULL, 0, &gli, sizeof(gli));
    if (!NT_SUCCESS(Status)) {
        NtClose(h);
        return Status;
    }

    // MSDN tells us to use IOCTL_DISK_GET_DRIVE_GEOMETRY_EX, but there are
    // some instances where it fails and IOCTL_DISK_GET_DRIVE_GEOMETRY succeeds -
    // such as with spanned volumes.
    Status = NtDeviceIoControlFile(h, NULL, NULL, NULL, &iosb, IOCTL_DISK_GET_DRIVE_GEOMETRY, NULL, 0, &dg, sizeof(dg));
    if (!NT_SUCCESS(Status)) {
        NtClose(h);
        return Status;
    }

    if (def_sector_size == 0) {
        sector_size = dg.BytesPerSector;

        if (sector_size == 0x200 || sector_size == 0)
            sector_size = 0x1000;
    } else {
        if (dg.BytesPerSector != 0 && (def_sector_size < dg.BytesPerSector || def_sector_size % dg.BytesPerSector != 0 || !is_power_of_two(def_sector_size / dg.BytesPerSector))) {
            NtClose(h);
            return STATUS_INVALID_PARAMETER;
        }

        sector_size = def_sector_size;
    }

    if (def_node_size == 0)
        node_size = 0x4000;
    else {
        if (def_node_size < sector_size || def_node_size % sector_size != 0 || !is_power_of_two(def_node_size / sector_size)) {
            NtClose(h);
            return STATUS_INVALID_PARAMETER;
        }

        node_size = def_node_size;
    }

    if (Callback) {
        ULONG pc = 0;
        Callback(PROGRESS, 0, (PVOID)&pc);
    }

    NtFsControlFile(h, NULL, NULL, NULL, &iosb, FSCTL_LOCK_VOLUME, NULL, 0, NULL, 0);

    if (is_mounted_multi_device(h, sector_size)) {
        Status = STATUS_ACCESS_DENIED;
        goto end;
    }

    do_full_trim(h);

    incompat_flags = def_incompat_flags;
    incompat_flags |= BTRFS_FEATURE_INCOMPAT_MIXED_BACKREF | BTRFS_FEATURE_INCOMPAT_BIG_METADATA;

    compat_ro_flags = def_compat_ro_flags;

    if (!Label) {
        empty_label.Buffer = NULL;
        empty_label.Length = empty_label.MaximumLength = 0;
        Label = &empty_label;
    }

    Status = write_btrfs(h, gli.Length.QuadPart, Label, sector_size, node_size, incompat_flags,
                         compat_ro_flags);

    NtFsControlFile(h, NULL, NULL, NULL, &iosb, FSCTL_DISMOUNT_VOLUME, NULL, 0, NULL, 0);

end:
    NtFsControlFile(h, NULL, NULL, NULL, &iosb, FSCTL_UNLOCK_VOLUME, NULL, 0, NULL, 0);

    NtClose(h);

    if (NT_SUCCESS(Status)) {
        btrfsus.Buffer = btrfs;
        btrfsus.Length = btrfsus.MaximumLength = (USHORT)(wcslen(btrfs) * sizeof(WCHAR));

        InitializeObjectAttributes(&attr, &btrfsus, 0, NULL, NULL);

        Status = NtOpenFile(&btrfsh, FILE_GENERIC_READ | FILE_GENERIC_WRITE, &attr, &iosb,
                            FILE_SHARE_READ, FILE_SYNCHRONOUS_IO_ALERT);

        if (NT_SUCCESS(Status)) {
            MOUNTDEV_NAME* mdn;
            ULONG mdnsize;

            mdnsize = (ULONG)(offsetof(MOUNTDEV_NAME, Name[0]) + DriveRoot->Length);
            mdn = malloc(mdnsize);

            mdn->NameLength = DriveRoot->Length;
            memcpy(mdn->Name, DriveRoot->Buffer, DriveRoot->Length);

            NtDeviceIoControlFile(btrfsh, NULL, NULL, NULL, &iosb, IOCTL_BTRFS_PROBE_VOLUME, mdn, mdnsize, NULL, 0);

            free(mdn);

            NtClose(btrfsh);
        }

        Status = STATUS_SUCCESS;
    }

    if (Callback) {
        bool success = NT_SUCCESS(Status);
        Callback(DONE, 0, (PVOID)&success);
    }

    return Status;
}

BOOL __stdcall FormatEx(DSTRING* root, STREAM_MESSAGE* message, options* opts, uint32_t unk1) {
    UNICODE_STRING DriveRoot, Label;
    NTSTATUS Status;

    if (!root || !root->string)
        return false;

    DriveRoot.Length = DriveRoot.MaximumLength = (USHORT)(wcslen(root->string) * sizeof(WCHAR));
    DriveRoot.Buffer = root->string;

    if (opts && opts->label && opts->label->string) {
        Label.Length = Label.MaximumLength = (USHORT)(wcslen(opts->label->string) * sizeof(WCHAR));
        Label.Buffer = opts->label->string;
    } else {
        Label.Length = Label.MaximumLength = 0;
        Label.Buffer = NULL;
    }

    Status = FormatEx2(&DriveRoot, FMIFS_HARDDISK, &Label, opts && opts->flags & FORMAT_FLAG_QUICK_FORMAT, 0, NULL);

    return NT_SUCCESS(Status);
}

void __stdcall SetSizes(ULONG sector, ULONG node) {
    if (sector != 0)
        def_sector_size = sector;

    if (node != 0)
        def_node_size = node;
}

void __stdcall SetIncompatFlags(uint64_t incompat_flags) {
    def_incompat_flags = incompat_flags;
}

void __stdcall SetCompatROFlags(uint64_t compat_ro_flags) {
    def_compat_ro_flags = compat_ro_flags;
}

void __stdcall SetCsumType(uint16_t csum_type) {
    def_csum_type = csum_type;
}

BOOL __stdcall GetFilesystemInformation(uint32_t unk1, uint32_t unk2, void* unk3) {
    // STUB - undocumented

    return true;
}

BOOL APIENTRY DllMain(HANDLE hModule, DWORD dwReason, void* lpReserved) {
    if (dwReason == DLL_PROCESS_ATTACH)
        module = (HMODULE)hModule;

    return true;
}
